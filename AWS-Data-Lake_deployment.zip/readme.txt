Original project name: AWS Data Lake
Exported on: 04/10/2019 19:50:10
Exported by: WIN-O1UR0KM3P4K\Administrator
