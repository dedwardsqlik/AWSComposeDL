Original project name: AWS Data Lake
Project type: HADOOPSPARK
Exported on: 08/12/2020 18:21:25
Exported by: WIN-O1UR0KM3P4K\Administrator
