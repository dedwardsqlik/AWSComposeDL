Original project name: AWS Data Lake
Project type: HADOOPSPARK
Exported on: 08/12/2020 18:20:14
Exported by: WIN-O1UR0KM3P4K\Administrator
